export const baseURL = "http://localhost:8085";
export const ahService = "/aham-service";
export const addDbConnection = "/addDb";
export const dbConnectionList = "/getDbConns";
export const addTraining = "/addTrainingData";
export const trainingData = "/getTrainingData";
export const chatGPT = "/get_response";
export const DBconnectioURL = "http://localhost:8000";
